import java.util.Scanner;

public class Zadanie11a {

    public static void main(String[] args) {
        Scanner readPassword = new Scanner(System.in);

        // Initialize variables
        String password;
        String correctPassword = "secretpassword";

        // Create while loop, to check the password
        while (true) {
            // Input password
            System.out.println("Podaj hasło: ");
            password = readPassword.nextLine();

            // Check that provided password is correct
            if (password.equals(correctPassword)) {
                System.out.println("Poprawne hasło");
                break;
            } else {
                System.out.println(password);
                System.out.println("Niepoprawne hasło");
            }
        }
    }

}
