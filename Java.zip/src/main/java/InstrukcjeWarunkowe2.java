public class InstrukcjeWarunkowe2 {

    public static void main(String[] args) {
        int x = -1;

        if (x < 0) {
            x = x * -1;
        }
         else {
           x = x;
        }

        System.out.println(x);

        int z = 0;
        z = (z < 0) ? z * -1 : z;

        System.out.println(z);
    }
}
