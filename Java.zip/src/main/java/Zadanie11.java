import java.util.Scanner;

public class Zadanie11 {
    public static void main(String[] args) {
        Scanner klawiautra = new Scanner(System.in);
        String haslo;

        do {
            System.out.print("Podaj hasło: ");
            haslo = klawiautra.nextLine();
            if (haslo.equals("secretpassword")) {
                System.out.println("Hasło jest poprawne");
            } else {
                System.out.println(haslo + "\nNiepoprane hasło");
            }
        } while (!(haslo.equals("secretpassword")));
    }
}
