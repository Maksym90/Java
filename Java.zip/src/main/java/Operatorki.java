public class Operatorki {

    public static void main(String[] args) {
        System.out.println(5 % 2);
        int i = 5;
        System.out.println(i);
        i++; // i = i + 1;
        System.out.println(i);
        // i--; // i = i - 1;
        i *= 2; // i = i * 2;
        System.out.println(i);

    }

}
