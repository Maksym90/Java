public class InkrementacjaIDekrementacja {
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
        int c;
        int d;

        c = ++b; // b = b + 1; c = b;
        d = a++; // d = a; a = a + 1;
        c++; // c = c + 1;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }
}
