import java.util.Scanner;

public class Zadanie6 {

    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        System.out.print("Proszę podaj hasło: ");
        String haslo = klawiatura.next();

        System.out.println("Podane haslo, to: " + haslo);

//        if (haslo.equals("secret")) {
//            System.out.println("Witaj w tajnym miejscu");
//        }

        switch(haslo) {
            case "secret":
                System.out.println("Witaj w tajnym miejscu");
        }

    }
}
