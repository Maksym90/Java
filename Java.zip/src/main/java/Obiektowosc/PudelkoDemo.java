package Obiektowosc;

public class PudelkoDemo {

    public static void main(String[] args) {
        Pudelko pudelko4= new Pudelko(-10,30,10,"czarny");
        System.out.println(pudelko4.getSzerokosc());
        System.out.println(pudelko4.getWysokosc());
        System.out.println(pudelko4.getGlebokosc());


        Pudelko pudelko3 = new Pudelko();
        System.out.println(pudelko3.getSzerokosc());
        System.out.println(pudelko3.getWysokosc());
        System.out.println(pudelko3.getGlebokosc());
        System.out.println(pudelko3.getKolor());

        Pudelko pudelko1 = new Pudelko();
        pudelko1.setWysokosc(20);
        pudelko1.setGlebokosc(2);
        pudelko1.setSzerokosc(20);

        Pudelko pudelko2 = new Pudelko();
        pudelko2.setGlebokosc(10);
        pudelko2.setSzerokosc(4);
        pudelko2.setWysokosc(2);

        System.out.println(pudelko1.obliczPojemnosc());
        System.out.println(pudelko2.obliczPojemnosc());

    }
}
