package Obiektowosc;

public class Pudelko {
    private double szerokosc;
    private double wysokosc;
    private double glebokosc;
    private String kolor;

    Pudelko() {
        szerokosc = 1;
        wysokosc = 1;
        glebokosc = 1;
        kolor = "czerwony";
    }

    // Pudelko pudelko4 = new Pudelko(10,20,30,"Czarny");
    Pudelko(double szerokosc, double wysokosc, double glebokosc, String kolor) {
        if (szerokosc <= 0) {
            System.out.println("Podales wartosc szerokosci mniejszą niż 0, w zwiazku z tym domyslnie ustawiam wartosc 1");
            this.szerokosc = 1;
        } else {
            this.szerokosc = szerokosc;
        }

        this.wysokosc = wysokosc;
        this.glebokosc = glebokosc;
        this.kolor = kolor;
    }

    // pudelko4.setWysokosc(30);
    public void setSzerokosc(double szerokosc) {
        if (szerokosc <= 0) {
            System.out.println("spadaj!!");
        } else {
            this.szerokosc = szerokosc;
        }
    }

    public void setWysokosc(double wysokosc) {
        this.wysokosc = wysokosc;
    }

    public void setGlebokosc(double glebokosc) {
        this.glebokosc = glebokosc;
    }

    public void setKolor(String kolor) {
        this.kolor = kolor;
    }

    public double getWysokosc () {
        return wysokosc;
    }

    public double getSzerokosc() {
        return szerokosc;
    }

    public double getGlebokosc() {
        return glebokosc;
    }

    public String getKolor() {
        return kolor;
    }

    double obliczPojemnosc() {
        return szerokosc * wysokosc * glebokosc;
    }
}
