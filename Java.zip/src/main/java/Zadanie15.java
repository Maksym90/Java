import java.util.Scanner;

public class Zadanie15 {

    public static void main(String[] args) {
        Scanner readNumber = new Scanner(System.in);

        // Initialize variables
        int num;
        int reversed = 0;

        // Get the number from user
        System.out.println("Jaką liczbę odwrócić?");
        num = readNumber.nextInt();

        // num = 1234;  0
        // digit      1
        // reversed 4321
        // Reverse the number using while loop
//        while(num != 0) {
//            int digit = num % 10;
//            reversed = reversed * 10 + digit;
//            num /= 10; // num = num /10
//        }

        // num      1234
        // digt     4
        // reversed 4

        // Reverse the number using for loop
        for(;num != 0; num /= 10) {
            int digit = num % 10;
            reversed = reversed * 10 + digit;
        }

        System.out.println("Wartość odwrócona : " + reversed);
    }
}


