import java.util.Scanner;

public class Zadanie5 {

    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        System.out.print("Podaj wartość a = ");
        int a = klawiatura.nextInt();

        System.out.print("Podaj wartość b = ");
        int b = klawiatura.nextInt();

        System.out.println("a = " + a + " ,b = " + b + " wynik dodawania, to " + (a + b));
        System.out.println("a = " + a + " ,b = " + b + " wynik odejmowania, to " + (a - b));
        System.out.println("a = " + a + " ,b = " + b + " wynik mnożenie, to " + (a * b));
        System.out.println("a = " + a + " ,b = " + b + " wynik dzielenie, to " + (a / b));
        System.out.println("a = " + a + " ,b = " + b + " wynik potegowania, to " + (int) (Math.pow(a,b)));

    }
}
