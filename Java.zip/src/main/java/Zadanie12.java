public class Zadanie12 {
    public static void main(String[] args) {
        int doKiedy = 45;
        int wypisywanaWartosc = 1;

        while (wypisywanaWartosc < doKiedy) {
            System.out.println(wypisywanaWartosc);
            wypisywanaWartosc += 2;
        }

        System.out.println("---------------");

        wypisywanaWartosc = 1;
        while (wypisywanaWartosc < doKiedy) {
            if (wypisywanaWartosc % 2 == 1) {
                System.out.println(wypisywanaWartosc);
            }
            wypisywanaWartosc++;
        }

        System.out.println("---------------");

        wypisywanaWartosc = 1;
        do {
            if (wypisywanaWartosc % 2 == 1) {
                System.out.println(wypisywanaWartosc);
            }
            wypisywanaWartosc++;
        } while (wypisywanaWartosc < doKiedy);

        for (wypisywanaWartosc = 1; wypisywanaWartosc < doKiedy; wypisywanaWartosc++){
            if (wypisywanaWartosc % 2 == 1) {
                System.out.println(wypisywanaWartosc);
            }
        }

    }
}
