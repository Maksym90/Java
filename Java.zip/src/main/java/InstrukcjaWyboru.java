public class InstrukcjaWyboru {

    public static void main(String[] args) {
        int x = 4;

        if (x == 1)
            System.out.println("x jest rowne 1");
          else if (x == 4)
              System.out.println("x jest rowne 4");
          else if (x == 78)
              System.out.println("x jest rowne78");
          else
              System.out.println("x nie jest rowny 1, 4, 78");


        System.out.println("--------------");

        switch (x) {
            case 1:
                System.out.println("x jest rowne 1");
                break;
            case 4:
                System.out.println("x jest rowne 4");
                break;
            case 78:
                System.out.println("x jest rowne 78");
                break;
            default:
                System.out.println("x nie jest rowny 1, 4, 78");
        }

        System.out.println("--------------");


    }
}
