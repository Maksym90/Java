public class LancuchZnakow2 {
    public static void main(String[] args) {
        char znak = '2';

//        String lancuchZnakow1 = "Ala ma kota";
//        String lancuchZnakow2 = "Ala ma kota";

       String lancuchZnakow1 = new String("Ala ma kota");
       String lancuchZnakow2 = new String("Ala ma kota");

        int x = 1;
        int y = 2;

        //System.out.println(lancuchZnakow1 == lancuchZnakow2);
        System.out.println(lancuchZnakow1.equals(lancuchZnakow2));

        System.out.println(lancuchZnakow1.length());
        System.out.println(lancuchZnakow1.isEmpty());
        System.out.println(lancuchZnakow1.toLowerCase());
        lancuchZnakow1 = lancuchZnakow1.toLowerCase();
        System.out.println(lancuchZnakow1);
        lancuchZnakow1 = lancuchZnakow1.toUpperCase();
        System.out.println(lancuchZnakow1);
        System.out.println(lancuchZnakow1.contains("ma"));
        System.out.println(lancuchZnakow1.lastIndexOf("OT"));
        //ALA MA KOTA
        String[] podzielonyTekst = lancuchZnakow1.split("");
        System.out.println(podzielonyTekst[0]); // ALA
        System.out.println(podzielonyTekst[1]); // MA
        System.out.println(podzielonyTekst[2]); // KOTA





    }
}
