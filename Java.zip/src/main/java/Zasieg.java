public class Zasieg {

    public static void main(String[] args) {
        int x = 10;

        if (x == 10) {
            int y = 100;
            System.out.println("y = " + y);
            y = 99;
            System.out.println(y);
        }

        //y = 10;
        x = 99;

        int i;

        for (i = 0; i < 3; i++) {
            int z = 0;
            System.out.println(i + z);
            z++;
        }

    }
}
