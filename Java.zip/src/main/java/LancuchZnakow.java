import java.lang.reflect.Array;
import java.util.Arrays;

public class LancuchZnakow {

    public static void main(String[] args) {
        int[] tablica1 = {3,4,5};
        //int[] tablica2 = tablica1;
        int[] tablica2 = Arrays.copyOfRange(tablica1,1,3);

        System.out.println(tablica1);
        System.out.println(tablica2);

        for (int pobranyElement : tablica1) {
            System.out.print(pobranyElement + " ");
        }

        System.out.println();

        for (int pobranyElement : tablica2) {
            System.out.print(pobranyElement + " ");
        }

        System.out.println();
        System.out.println();

        tablica1[0] = 9;

        for (int pobranyElement : tablica1) {
            System.out.print(pobranyElement + " ");
        }

        System.out.println();

        for (int pobranyElement : tablica2) {
            System.out.print(pobranyElement + " ");
        }

    }
}
