import java.util.Scanner;

public class Zadanie7 {

    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        System.out.print("Proszę podaj imię: ");
        String imie = klawiatura.nextLine();
        //System.out.println(imie); John Wick
        String[] imiePoPodziale = imie.split(" ");

        System.out.println("Podane imię, to: " + imiePoPodziale[0]);

        if (imie.equals("John Wick")) {
            System.out.println("Widzę, że znowu pracujesz " + imiePoPodziale[0]);
        } else {
            System.out.println("Witaj " + imie);
        }
    }
}
