public class Macierz {
    public static void main(String[] args) {
        double[] tablica = new double[5];
//              tablica[0] = 1;

        for (int i = 0; i <= tablica.length - 1; i++){
            tablica[i] = Math.random();
            System.out.println(tablica[i]);
        }

//        for (int i = 0; i <= tablica.length - 1; i++){
//            System.out.println(tablica[i]);
//        }

        System.out.println("-----------");

        int[][] macierz = new int[3][2];
        //macierz[2][0] = 4;

        for (int i = 0; i <= 2; i++){
            for (int j = 0; j <= 1 ;j++){
                macierz[i][j]= i + j;
                System.out.print(macierz[i][j] + " ");
            }
            System.out.println();
        }




    }
}
