public class InstrukcjeWarunkowe {

    public static void main(String[] args) {
        int x = 1;

        // == cos jest rowne
        // != cos jest różne
        // <= mniejsze lub równe
        // >= większe lub równe

        if (x < 0) {
            System.out.println("x jest mniejsze od 0");
        } else if (x == 0) {
            System.out.println("x jest równe 0");
        } else {
            System.out.println("x jest wieksze od 0");
        }

        // and &&
        // or ||

        int a = 1, b = 1;

        if ((a == 0) && (b == 0)) {
            System.out.println("a jest rowne 0 i jednoczesnie b jest rowne 0");
        }

        if ((a == 0) || (b == 0)) {
            System.out.println("a jest równe 0 lub b jest równe 0");
        }

        int liczba = -2;
        if ((liczba > -4 && liczba <= -1) || (liczba > 1 && liczba <= 4)) {
            System.out.println("tak");
        } else {
            System.out.println("nie");
        }

    }

}
