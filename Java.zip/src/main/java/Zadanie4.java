import java.util.Arrays;
import java.util.Scanner;

public class Zadanie4 {
    public static void main(String[] args) {
//        double x;
//        System.out.println("Podaj wartość całkowitą: ");
//        Scanner klawiatura = new Scanner(System.in);
//        x = klawiatura.nextDouble();
//        System.out.println("zmienna x, ma wartosc: " + x);

        int tablica1[] = {1,2,3};
        System.out.println(tablica1);
        int tablica2[] = Arrays.copyOf(tablica1,3);
        System.out.println(tablica1);
        System.out.println(tablica2);
        tablica2[0] = 9;

        for (int element : tablica1) {
            System.out.print(element + " ");
        }

        System.out.println();

        for (int element : tablica2) {
            System.out.print(element + " ");
        }

        String string1 = "ala";
        String string2 = string1;
        System.out.println(string1 == string2);

    }
}
