public class HelloWorld {

    public static void main(String[] args) {

        int zmiennaCalkowitoliczbowa; // deklaracja zmiennej
        zmiennaCalkowitoliczbowa = 127; //inicjalizacja zmiennej wartoscia

        float zmiennaZmiennoprzecinkowa = 3.14f; //deklaracja i inicjalizacja zmiennej
        zmiennaZmiennoprzecinkowa = 5.15f;

//        System.out.println("Ala ma kota\n");
//        System.out.print("Bartek ma psa");
        System.out.println(zmiennaCalkowitoliczbowa);
        System.out.println(zmiennaZmiennoprzecinkowa);

        char zmiennaZnakowaPierwsza = 169;
        char zmiennaZnakowaDruga = 'b';
        System.out.println("W pudelku jest wpisana wartosc " + zmiennaZnakowaPierwsza);
        System.out.println(zmiennaZnakowaPierwsza + zmiennaZnakowaDruga);

        boolean zmiennaLogiczna = false;
        System.out.println(zmiennaLogiczna);

    }
}


