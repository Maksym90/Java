import java.util.Scanner;

public class Cwiczenie15 {
    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);

        System.out.print("Podaj ilosc wierszy: ");
        int wiersze = klawiatura.nextInt();

        System.out.print("Podaj ilosc kolumn: ");
        int kolumny = klawiatura.nextInt();

        int[][] macierz = new int[wiersze][kolumny];

        for (int i = 0; i <= wiersze - 1; i++) {
            for (int j = 0; j <= kolumny - 1; j++) {
                macierz[i][j] = (i + 1) * (j + 1);
            }
        }

        for (int i = 0; i <= wiersze - 1; i++) {
            for (int j = 0; j <= kolumny - 1; j++) {
                if (macierz[i][j] < 10) {
                    System.out.print(" " + macierz[i][j] + " ");
                } else {
                    System.out.print(macierz[i][j] + " ");
                }
            }
            System.out.println();
        }

        System.out.println("---------");
        for (int i = 1; i <= wiersze; i++) {
            for (int j = 1; j <= kolumny; j++) {
                if (i * j < 10) {
                    System.out.print("  " + (i * j) + " ");
                } else if (i * j < 100) {
                    System.out.print(" " + (i * j) + " ");
                } else {
                    System.out.print((i * j) + " ");
                }
            }
            System.out.println();
        }

    }
}
