public class Tablice {

    public static void main(String[] args) {
        int[] tablica = {5,8,9,10,-5};
        System.out.println(tablica[3]);

        tablica[3] = 23;
        System.out.println(tablica[3]);
        System.out.println(tablica.length);

        double[] tablica2 = new double[5];
        tablica2[0] = Math.random();
        System.out.println(tablica2[0]);




    }
}
