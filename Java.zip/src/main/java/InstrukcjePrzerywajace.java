public class InstrukcjePrzerywajace {
    public static void main(String[] args) {

        int x = 1;
        int z = 2;
        switch(x) {
            case 1:
                if (z == 1){
                   System.out.println(1);
                   System.out.println("fdfdfdfd");
                }
                break;
            case 2:
                System.out.println(2);
                break;
            default:
                System.out.println("aaaaa");
        }

        System.out.println("-------------");

        x = 0;
        while (x < 5) {
            System.out.println(x);
            x++;
            if (x == 2) {
                break;
            }
        }

        System.out.println("-------");

        x = 0;
        while (x < 5) {
            if (x == 2) {
                x++;
                continue;
            }
            System.out.println(x);
            x++;
        }
    }
}
