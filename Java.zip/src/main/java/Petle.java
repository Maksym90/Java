public class Petle {
    public static void main(String[] args) {

//        int x = 9;
//        while (x >= 0) {
//            System.out.println(x);
//            x--;
//        }

        int x = 0;
        while (x < 10) {
            System.out.println(x);
            x++;
        }
        System.out.println("-- koniec petli while ---");

        int y = 0;
        do {
            System.out.println(y);
            y++;
        } while (y < 10);

        System.out.println("-- koniec petli do-while ---");

        for (int z = 0; z < 10; z++) {
            System.out.println(z);
        }
        System.out.println("-- koniec petli for  ---");

    }
}
