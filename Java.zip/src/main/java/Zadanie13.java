public class Zadanie13 {
    public static void main(String[] args) {
        int[] tablica = new int[10];
//        tablica[0] = Math.random();
//        tablica[1] = Math.random();
//        tablica[2] = Math.random();

        int minimum;
        int maksimum;

        for(int indeks = 0; indeks <= tablica.length - 1; indeks++) {
            tablica[indeks] = (int) (Math.random() * 20 - 10);
        }

        minimum = tablica[0];
        maksimum = tablica[0];

        for(int indeks = 0; indeks <= tablica.length - 1; indeks++) {
            System.out.print(tablica[indeks] + " ");
            if (tablica[indeks] < minimum) {
                minimum = tablica[indeks];
            } else if (tablica[indeks] > maksimum) {
                maksimum = tablica[indeks];
            }
        }

        System.out.println("\nWartosc minimalna, to " + minimum);
        System.out.println("Wartosc maksymalna, to " + maksimum);

    }
}
